# Database Restore Playbook
1. Stop application services
2. Verify backup checksum
3. Extract backup archive
4. Restore database files
5. Start application services
6. Validate connectivity and data integrity
